/**
 * Gen maps function without anything
 */
(function($){
	$.fn.evoGenmaps = function(opt){

	};
}(jQuery));